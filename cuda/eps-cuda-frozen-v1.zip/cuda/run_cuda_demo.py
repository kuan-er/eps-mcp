"""Replay the saved EPS demo through a CUDA visibility and hit-aggregation prototype.

Requires NumPy, an NVIDIA driver and NVRTC. The Windows default reads the
local EPS MCP configuration. --fixture-dir loads a self-contained replay on
Windows or Linux, including saved Windows and native EPS reference grids.
"""

import argparse
from contextlib import nullcontext
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEMO = HERE.parent / "eps-native-demo"
DRIVER = c.c_int
HANDLE = c.c_void_p
DEVICE_PTR = c.c_uint64
SIZE = c.c_size_t
METRICS = ("distance", "cosinc", "cosforward", "cosnormalz", "ndcx", "ndcy")
sys.path.insert(0, str(DEMO))
from verify_deposition import compare


def native_camera_constants(camera):
    """Convert CameraData to the constants actually uploaded by the EPS renderer."""
    forward = np.asarray(camera["forward"], dtype=np.float32)
    x, y, z = forward
    length = np.sqrt((x*x + y*y) + z*z)
    return np.r_[np.asarray(camera["position"], dtype=np.float32), forward / length]


def native_inverse_w(w, reciprocal):
    inverse = w.copy()
    nonunit = inverse != np.float32(1)
    if np.any(nonunit):
        inverse[nonunit] = reciprocal(inverse[nonunit])
    return inverse


def snap_viewport_xy(clip_xy, inverse_w, size):
    half_size = np.float32(size / 2)
    scale = np.array([half_size, -half_size], np.float32)
    # The viewport scales clip coordinates before applying reciprocal W.
    screen = (clip_xy * scale) * inverse_w[..., None] + half_size
    return np.rint(screen * 256) / 256


def clip_orthographic_depth(clip, world, normals, uv, *, reciprocal, size=256):
    """Clip orthographic input against 0 <= Z <= W before viewport snapping.

    X/Y use a guard band and are bounded by the integer viewport during
    coverage. Keep all vertex attributes together at clip intersections.
    """
    z = clip[:, :, 2]
    accepted = np.all((z >= 0) & (z <= 1), axis=1)
    if np.all(accepted):
        return clip, world, normals, uv
    attributes = np.concatenate((clip, world, normals, uv), axis=2)
    crosses_both = np.any(z < 0, axis=1) & np.any(z > 1, axis=1)
    touches_boundary = crosses_both & np.any((z == 0) | (z == 1), axis=1)
    with_weights = np.concatenate((attributes, np.broadcast_to(np.eye(3, dtype=np.float32), (*attributes.shape[:2], 3))), axis=2)
    polygons = {i: [(v, False) for v in with_weights[i]] for i in np.flatnonzero(~accepted)}
    for near_plane in (True, False):
        crossings = []
        for face, polygon in polygons.items():
            if not polygon:
                continue
            clipped = []
            previous = polygon[-1][0]
            double_clip = crosses_both[face]
            for current, already_clipped in polygon:
                prev_distance = previous[2] if near_plane else previous[3] - previous[2]
                curr_distance = current[2] if near_plane else current[3] - current[2]
                crossed = prev_distance < 0 < curr_distance or curr_distance < 0 < prev_distance
                # Native dual-plane clipping emits the intersection on an
                # outside/contact edge and also retains the on-plane input.
                if touches_boundary[face]:
                    crossed |= (prev_distance < 0 == curr_distance or curr_distance < 0 == prev_distance)
                if crossed:
                    # Use the same endpoint order for shared edges in opposite
                    # winding. Each generated vertex is stored once as float32.
                    inside, outside, di, do = ((previous, current, prev_distance, curr_distance)
                                               if prev_distance >= 0 else
                                               (current, previous, curr_distance, prev_distance))
                    vertex = np.empty_like(inside)
                    crossings.append((vertex, inside, outside, di, do, double_clip))
                    clipped.append((vertex, True))
                if curr_distance >= 0:
                    clipped.append((current, already_clipped))
                previous = current
            polygons[face] = clipped
        if crossings:
            vertices, inside, outside, di, do, double_clip = zip(*crossings)
            di, do = np.asarray(di, dtype=np.float32), np.asarray(do, dtype=np.float32)
            denominator = di - do
            inverse = reciprocal(denominator.copy())
            inside, outside = np.asarray(inside), np.asarray(outside)
            interpolated = inside * (-do * inverse)[:, None] + outside * (di * inverse)[:, None]
            dual = np.asarray(double_clip, dtype=bool)
            if near_plane:
                # With original W=1, the spatial W numerator is the near
                # denominator. Keep it for the second plane's distance.
                interpolated[dual, 3] = denominator[dual] * inverse[dual]
            else:
                interpolated[dual] = (inside[dual] * -do[dual, None] + outside[dual] * di[dual, None]) * inverse[dual, None]
            interpolated[:, 2] = 0 if near_plane else interpolated[:, 3]
            for vertex, value in zip(vertices, interpolated, strict=True):
                vertex[:] = value
    ranked = []
    for face, polygon in polygons.items():
        if crosses_both[face] and polygon:
            if touches_boundary[face]:
                # Rank the stored clip positions before materializing the
                # original attributes at their accumulated weights.
                anchor = min(range(len(polygon)), key=lambda i: (polygon[i][0][0], polygon[i][0][1], -polygon[i][0][3]))
                polygon = polygon[anchor:] + polygon[:anchor]
            materialized = []
            for vertex, generated in polygon:
                products = vertex[12:, None] * attributes[face]
                point = (products[0] + products[1]) + products[2]
                point[2] = point[3] if vertex[2] == vertex[3] else vertex[2]
                materialized.append((point, generated))
            polygons[face] = materialized
            if len(polygon) > 3 and not touches_boundary[face]:
                ranked.append((face, list(range(len(polygon)))))
        elif len(polygon) == 4:
            generated = [i for i, (_, flag) in enumerate(polygon) if flag]
            if len(generated) == 2:
                ranked.append((face, generated))
    if ranked:
        points = np.array([polygons[face][i][0][:4] for face, indices in ranked for i in indices])
        inverse_w = native_inverse_w(points[..., 3], reciprocal)
        positions = snap_viewport_xy(points[..., :2], inverse_w, size)
        normalized = points[..., :2] * inverse_w[:, None]
        start = 0
        for face, indices in ranked:
            keys = normalized if crosses_both[face] else positions
            xy = keys[start:start + len(indices)]
            anchor = indices[min(range(len(xy)), key=lambda i: tuple(xy[i]))]
            polygon = polygons[face]
            polygons[face] = polygon[anchor:] + polygon[:anchor]
            start += len(indices)
    emitted = []
    for face, vertices in enumerate(attributes):
        if accepted[face]:
            emitted.append(vertices)
            continue
        polygon = polygons[face]
        polygon = [v[:12] for v, _ in polygon]
        for i in range(1, len(polygon) - 1):
            emitted.append(np.stack((polygon[0], polygon[i], polygon[i + 1])))
    result = np.asarray(emitted, dtype=np.float32).reshape(-1, 3, 12)
    return result[:, :, :4], result[:, :, 4:7], result[:, :, 7:10], result[:, :, 10:12]


def bind(lib, name, *types):
    fn = getattr(lib, name)
    fn.argtypes = types
    fn.restype = c.c_int
    return fn


def driver_call(lib, name, types, *values):
    code = bind(lib, name, *types)(*values)
    if code:
        error = c.c_char_p()
        bind(lib, "cuGetErrorName", c.c_int, c.POINTER(c.c_char_p))(code, c.byref(error))
        raise RuntimeError(f"{name}: {error.value!r} ({code})")


def cubin_for(nvrtc_dir, major, minor, source):
    with os.add_dll_directory(str(nvrtc_dir)) if os.name == "nt" else nullcontext():
        if os.name == "nt":
            # NVRTC loads this module by name; use the same wheel as the compiler.
            c.WinDLL(str(nvrtc_dir / "nvrtc-builtins64_126.dll"))
            nvrtc = c.WinDLL(str(nvrtc_dir / "nvrtc64_120_0.dll"))
        else:
            nvrtc = c.CDLL(str(nvrtc_dir / "libnvrtc.so.12") if nvrtc_dir else "libnvrtc.so.12")
        program = HANDLE()

        def call(name, types, *values):
            status = bind(nvrtc, name, *types)(*values)
            if status:
                raise RuntimeError(f"{name}: NVRTC error {status}")

        version = [c.c_int(), c.c_int()]
        call("nvrtcVersion", [c.POINTER(c.c_int)] * 2, *(c.byref(v) for v in version))
        call("nvrtcCreateProgram", [c.POINTER(HANDLE), c.c_char_p, c.c_char_p,
                                    c.c_int, HANDLE, HANDLE],
             c.byref(program), source, b"raster_hits.cu", 0, None, None)
        try:
            flags = [f"--gpu-architecture=sm_{major}{minor}".encode(), b"--fmad=false"]
            argv = (c.c_char_p * len(flags))(*flags)
            status = bind(nvrtc, "nvrtcCompileProgram", HANDLE, c.c_int,
                          c.POINTER(c.c_char_p))(program, len(flags), argv)
            if status:
                length = SIZE()
                call("nvrtcGetProgramLogSize", [HANDLE, c.POINTER(SIZE)], program, c.byref(length))
                log = c.create_string_buffer(length.value)
                call("nvrtcGetProgramLog", [HANDLE, HANDLE], program, log)
                raise RuntimeError(log.value.decode(errors="replace"))
            length = SIZE()
            call("nvrtcGetCUBINSize", [HANDLE, c.POINTER(SIZE)], program, c.byref(length))
            cubin = c.create_string_buffer(length.value)
            call("nvrtcGetCUBIN", [HANDLE, HANDLE], program, cubin)
            return cubin, ".".join(str(v.value) for v in version)
        finally:
            call("nvrtcDestroyProgram", [c.POINTER(HANDLE)], c.byref(program))


class CudaRaster:
    def __init__(self, basis, nvrtc_dir):
        self.basis = basis
        self.nvrtc_dir = nvrtc_dir
        self.driver = c.WinDLL("nvcuda.dll") if os.name == "nt" else c.CDLL("libcuda.so.1")
        self.context, self.module, self.kernel = HANDLE(), HANDLE(), HANDLE()
        self.reduce_kernel = HANDLE()
        self.finalize_kernel = HANDLE()
        self.project_kernel = HANDLE()
        self.clip_reciprocal_kernel = HANDLE()
        self.launches = 0
        self.seconds = 0.

    def call(self, name, types, *args):
        driver_call(self.driver, name, types, *args)

    def __enter__(self):
        self.call("cuInit", [c.c_uint], 0)
        device, driver_version = DRIVER(), c.c_int()
        self.call("cuDeviceGet", [c.POINTER(DRIVER), c.c_int], c.byref(device), 0)
        self.call("cuDriverGetVersion", [c.POINTER(c.c_int)], c.byref(driver_version))
        name = c.create_string_buffer(256)
        self.call("cuDeviceGetName", [HANDLE, c.c_int, DRIVER], name, len(name), device)
        capabilities = []
        for attr in (75, 76):
            value = c.c_int()
            self.call("cuDeviceGetAttribute", [c.POINTER(c.c_int), c.c_int, DRIVER],
                      c.byref(value), attr, device)
            capabilities.append(value.value)
        source = (HERE / "raster_hits.cu").read_bytes()
        cubin, compiler = cubin_for(self.nvrtc_dir, *capabilities, source)
        self.info = {"device": name.value.decode(), "compute_capability": capabilities,
                     "cuda_driver_api_version": driver_version.value, "nvrtc": compiler,
                     "kernel_source_sha256": hashlib.sha256(source).hexdigest()}
        self.call("cuCtxCreate_v2", [c.POINTER(HANDLE), c.c_uint, DRIVER],
                  c.byref(self.context), 0, device)
        try:
            self.call("cuModuleLoadData", [c.POINTER(HANDLE), HANDLE], c.byref(self.module), cubin)
            self.call("cuModuleGetFunction", [c.POINTER(HANDLE), HANDLE, c.c_char_p],
                      c.byref(self.kernel), self.module, b"raster_hits")
            self.call("cuModuleGetFunction", [c.POINTER(HANDLE), HANDLE, c.c_char_p],
                      c.byref(self.reduce_kernel), self.module, b"reduce_native_capture")
            self.call("cuModuleGetFunction", [c.POINTER(HANDLE), HANDLE, c.c_char_p],
                      c.byref(self.finalize_kernel), self.module, b"finalize_native_hits")
            self.call("cuModuleGetFunction", [c.POINTER(HANDLE), HANDLE, c.c_char_p],
                      c.byref(self.project_kernel), self.module, b"project_native_vertices")
            self.call("cuModuleGetFunction", [c.POINTER(HANDLE), HANDLE, c.c_char_p],
                      c.byref(self.clip_reciprocal_kernel), self.module, b"clip_depth_reciprocals")
        except BaseException:
            self.__exit__()
            raise
        return self

    def __exit__(self, *_):
        if self.context:
            self.call("cuCtxDestroy_v2", [HANDLE], self.context)

    def __call__(self, triangles, normals, uv, position, forward, up, cfg, side, *, deadline=None):
        if deadline is not None and time.monotonic() > deadline:
            raise TimeoutError("CUDA replay deadline exceeded")
        if not len(triangles):
            return None
        size = cfg["camera_pixels"]
        right, camera_up, forward = self.basis(forward, up)
        projected = (triangles - position) @ np.column_stack((right, camera_up, forward))
        screen = projected.copy()
        screen[:, :, 0] = (projected[:, :, 0] / (cfg["fan_width_mm"] / 2000.) + 1) * size / 2
        screen[:, :, 1] = (1 - projected[:, :, 1] / (cfg["fan_height_mm"] / 2000.)) * size / 2
        return self._raster(screen, triangles, normals, uv, np.r_[position, forward], size, side,
                            cfg["near_plane_m"], cfg["far_plane_m"], False)

    def from_native_camera(self, triangles, normals, uv, camera, size, side, *, buffers=None):
        """Replay a captured EPS orthographic camera on the CUDA diagnostic path."""
        world = np.asarray(triangles, dtype=np.float32)
        vertex_normals = np.asarray(normals, dtype=np.float32)
        if vertex_normals.shape == (len(world), 3):
            vertex_normals = np.broadcast_to(vertex_normals[:, None, :], world.shape)
        if vertex_normals.shape != world.shape:
            raise ValueError("Expected one normal per face or one per triangle vertex")
        lengths = np.linalg.norm(vertex_normals, axis=-1, keepdims=True)
        if np.any(~np.isfinite(lengths) | (lengths == 0)):
            raise ValueError("The native camera replay requires finite nonzero normals")
        vertex_normals = vertex_normals / lengths
        clip = self.project_native_vertices(world, camera["view"], camera["projection"])
        if not np.all(clip[:, :, 3] == 1):
            raise ValueError("The native camera replay requires an orthographic matrix")
        clip, world, vertex_normals, uv = clip_orthographic_depth(
            clip, world, vertex_normals, np.asarray(uv, dtype=np.float32),
            reciprocal=self.clip_depth_reciprocals, size=size)
        if not len(clip):
            if buffers is not None:
                buffers.update(texel=np.zeros((size, size), np.uint32),
                               position=np.zeros((size, size, 4), np.float16),
                               normal=np.zeros((size, size, 4), np.float16))
            return None
        reciprocal_w = native_inverse_w(clip[:, :, 3], self.clip_depth_reciprocals)
        screen = clip.copy()
        screen[:, :, :2] = snap_viewport_xy(clip[:, :, :2], reciprocal_w, size)
        screen[:, :, 2] = clip[:, :, 2] * reciprocal_w
        screen[:, :, 3] = reciprocal_w
        weighted_world = world * reciprocal_w[..., None]
        weighted_normals = vertex_normals * reciprocal_w[..., None]
        weighted_uv = uv * reciprocal_w[..., None]
        return self._raster(screen, weighted_world, weighted_normals, weighted_uv, native_camera_constants(camera),
                            size, side, 0., 1., True, buffers=buffers)

    def project_native_vertices(self, world, view, projection):
        world, view, projection = (np.ascontiguousarray(v, dtype=np.float32)
                                   for v in (world, view, projection))
        if world.shape[-1] != 3 or view.shape != (4, 4) or projection.shape != (4, 4):
            raise ValueError("Expected XYZ vertices and two 4x4 matrices")
        output = np.empty((*world.shape[:-1], 4), dtype=np.float32)
        if not world.size:
            return output
        allocated = []
        try:
            args = [self._upload(v, allocated) for v in (world, view, projection)]
            target = self._allocate(output.nbytes, allocated)
            count = world.size // 3
            self._launch(self.project_kernel, count, args + [c.c_int(count), target])
            self._download(output, target)
        finally:
            self._free(allocated)
        return output

    def clip_depth_reciprocals(self, distances):
        allocated = []
        try:
            device = self._upload(distances, allocated)
            self._launch(self.clip_reciprocal_kernel, distances.size, [device, c.c_int(distances.size)])
            self._download(distances, device)
        finally:
            self._free(allocated)
        return distances

    def reduce_native_capture(self, texel, position, normal, camera, side):
        size, height = texel.shape
        if height != size or position.shape != (size, size, 4) or normal.shape != position.shape:
            raise ValueError("Expected a square captured EPS G-buffer")
        arrays = (np.ascontiguousarray(texel, dtype=np.uint32),
                  np.ascontiguousarray(position, dtype=np.float32),
                  np.ascontiguousarray(normal, dtype=np.float32),
                  np.ascontiguousarray(native_camera_constants(camera), dtype=np.float64))
        return self._dispatch(self.reduce_kernel, arrays, size, side, (c.c_int(size), c.c_int(side)))

    def _raster(self, screen, triangles, normals, uv, camera, size, side, near_z, far_z, native_camera,
                *, buffers=None):
        if screen.shape[-1] == 3:
            screen = np.concatenate((screen, np.ones_like(screen[..., :1])), axis=-1)
        arrays = tuple(np.ascontiguousarray(v, dtype=np.float64)
                       for v in (screen, triangles, normals, uv, camera))
        constants = (c.c_int(len(triangles)), c.c_int(size), c.c_int(side),
                     c.c_double(near_z), c.c_double(far_z))
        return self._dispatch(self.kernel, arrays, size, side, constants,
                              raster_mode=native_camera, buffers=buffers)

    def _dispatch(self, kernel, arrays, size, side, constants, *, raster_mode=None, buffers=None):
        started = time.perf_counter()
        aggregates = np.empty((side * side, 7), dtype=np.uint32)
        allocated = []

        try:
            args = [self._upload(array, allocated) for array in arrays]
            out = self._allocate(aggregates.nbytes, allocated)
            self.call("cuMemsetD32_v2", [DEVICE_PTR, c.c_uint, SIZE], out, 0, aggregates.size)
            args.extend(constants)
            args.append(out)
            if raster_mode is not None:
                pixel_ptr = DEVICE_PTR(0)
                if buffers is not None:
                    pixels = np.empty((size, size, 9), dtype=np.uint32)
                    pixel_ptr = self._allocate(pixels.nbytes, allocated)
                    self.call("cuMemsetD32_v2", [DEVICE_PTR, c.c_uint, SIZE], pixel_ptr, 0, pixels.size)
                args.extend((c.c_int(raster_mode), pixel_ptr))
            self._launch(kernel, size * size, args)
            if raster_mode is not False:
                texel_count = len(aggregates)
                self._launch(self.finalize_kernel, texel_count, [out, c.c_int(texel_count)])
            self._download(aggregates, out)
            if buffers is not None:
                self._download(pixels, pixel_ptr)
                buffers.update(texel=pixels[..., 0].copy(), position=pixels[..., 1:5].view(np.float32).astype(np.float16),
                               normal=pixels[..., 5:].view(np.float32).astype(np.float16))
            self.launches += 1
        finally:
            self._free(allocated)

        ids = np.flatnonzero(aggregates[:, 0])
        self.seconds += time.perf_counter() - started
        if not len(ids):
            return None
        sparse = aggregates[ids]
        counts = sparse[:, 0].astype(np.int64)
        if raster_mode is False:
            sums = sparse[:, 1:].view(np.int32).astype(np.float32)
            inv_count = (np.float32(1) / counts.astype(np.float32))[:, None]
            scale = np.array([1e-3] + [1e-6] * 5, dtype=np.float32)
            means = sums * scale * inv_count
        else:
            means = sparse[:, 1:].view(np.float32)
        return {"texel": ids, "count": counts, "visible_pixels": int(counts.sum()),
                **dict(zip(METRICS, means.T, strict=True))}

    def _allocate(self, nbytes, allocated):
        ptr = DEVICE_PTR()
        self.call("cuMemAlloc_v2", [c.POINTER(DEVICE_PTR), SIZE], c.byref(ptr), nbytes)
        allocated.append(ptr)
        return ptr

    def _upload(self, array, allocated):
        ptr = self._allocate(array.nbytes, allocated)
        self.call("cuMemcpyHtoD_v2", [DEVICE_PTR, HANDLE, SIZE], ptr, array.ctypes.data, array.nbytes)
        return ptr

    def _download(self, array, ptr):
        self.call("cuMemcpyDtoH_v2", [HANDLE, DEVICE_PTR, SIZE], array.ctypes.data, ptr, array.nbytes)

    def _free(self, allocated):
        for ptr in reversed(allocated):
            self.call("cuMemFree_v2", [DEVICE_PTR], ptr)

    def _launch(self, kernel, count, args):
        params = (HANDLE * len(args))(*(c.addressof(x) for x in args))
        self.call("cuLaunchKernel", [HANDLE] + [c.c_uint] * 7 + [HANDLE, HANDLE, HANDLE],
                  kernel, (count + 127) // 128, 1, 1, 128, 1, 1, 0, None, params, None)


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def differences(left, right):
    if left is None or right is None:
        return [] if left is right else ["empty_mismatch"]
    return [key for key in left if not np.array_equal(left[key], right[key])]


def occlusion_control(recon, raster):
    # The foreground triangle covers the back triangle exactly in projection,
    # but writes to different UV texels; verify that adding the back has no effect.
    front = np.array([[[-.05, -.05, .2], [.05, -.05, .2], [0., .05, .2]]])
    back = front + [0., 0., .1]
    tris = np.concatenate((back, front))
    nrm = np.array([[0., 0., -1.]] * 2)
    uv = np.array([[[.65, .65], [.85, .65], [.75, .85]],
                   [[-.1, .05], [.1, .05], [0., .2]]])
    camera = (np.zeros(3), np.array([0., 0., 1.]), np.array([0., 1., 0.]))
    cfg = dict(camera_pixels=64, fan_width_mm=200., fan_height_mm=200.,
               near_plane_m=.001, far_plane_m=.6)
    cpu = recon.raster_hits(tris, nrm, uv, *camera, cfg, 32)
    cuda = raster(tris, nrm, uv, *camera, cfg, 32)
    only_front = raster(front, nrm[1:], uv[1:], *camera, cfg, 32)
    if cpu is None or cuda is None:
        raise RuntimeError("occlusion control did not rasterize a visible surface")
    return {"visible_pixels": cuda["visible_pixels"],
            "cpu_vs_cuda_hit_fields_different": differences(cpu, cuda),
            "adding_fully_occluded_face_changes_cuda": bool(differences(cuda, only_front))}


def workspace_cases(config_path):
    import tomllib

    spec = tomllib.loads(config_path.read_text(encoding="utf-8-sig"))["mcp_servers"]["eps_reconstruction"]
    sys.path.insert(0, str(Path(spec["args"][0]).parent))
    import reconstructed_deposition as recon
    from spray_core import load_mesh

    evidence = read(DEMO / "comparison.json")
    motions = read(DEMO / "recorded-motion.json")
    case_root = Path(spec["env"]["EPS_MCP_CASE_ROOT"])
    profile_dir = Path(spec["env"]["EPS_MCP_ASSET_CATALOG"]).parent.parent / "profiles"
    cfg = recon.configuration(read(profile_dir / "eps_reconstruction_reference_v1.json"))
    cfg["kernel_parameters"].update(evidence["matched_project_parameters"])
    cfg["atlas_texels_per_cell"] = 256

    def inputs():
        for item, motion in zip(evidence["results"], motions, strict=True):
            label = item["label"]
            case = case_root / item["case_id"]
            mesh = load_mesh(case / "mesh.npz", case / "summary.json")
            with np.load(case / "face_atlas.npz", allow_pickle=False) as archive:
                uv = archive["uv"]
            with np.load(DEMO / f"{label}-deposition.npz", allow_pickle=False) as archive:
                native, previous = archive["native"], archive["cpu_uv512"]
            trajectory = {**motion, "world_transform": read(case / "case.json")["planning_to_world"]}
            yield label, mesh, uv, trajectory, native, previous, None

    return cfg, inputs()


def fixture_cases(fixture_dir):
    manifest = read(fixture_dir / "manifest.json")

    def inputs():
        for label, trajectory in manifest["trajectories"].items():
            with np.load(fixture_dir / f"{label}.npz", allow_pickle=False) as archive:
                mesh = {k: archive[k] for k in ("vertices", "faces", "normals")}
                uv, native, cpu, windows = (archive[k] for k in
                                            ("uv", "native", "cpu", "windows_cuda"))
            yield label, mesh, uv, trajectory, native, cpu, windows

    return manifest["config"], inputs()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nvrtc-dir", type=Path, default=(
        ROOT / "work/cuda-runtime/nvidia/cuda_nvrtc/bin" if os.name == "nt" else None))
    parser.add_argument("--config", type=Path, default=Path.home() / ".codex/config.toml")
    parser.add_argument("--fixture-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, default=HERE)
    args = parser.parse_args()
    cfg, inputs = (fixture_cases(args.fixture_dir) if args.fixture_dir
                   else workspace_cases(args.config))
    import reconstructed_deposition as recon

    args.output_dir.mkdir(parents=True, exist_ok=True)
    report = {"scope": "CUDA raster visibility, UV addressing and integer hit aggregation; "
                       "existing host pose sampling, ComputeDelta and final accumulation.",
              "reference_scope": "Saved raw native EPS and CPU grids; the same recorded motion "
                                 "is replayed on CPU and CUDA, with the reconstructed sampling clock.",
              "camera_pixels": cfg["camera_pixels"], "tick_interval_s": cfg["tick_interval_s"],
              "results": []}
    cpu_raster = recon.raster_hits
    nvrtc_dir = args.nvrtc_dir.resolve() if args.nvrtc_dir is not None else None
    with CudaRaster(recon.camera_basis, nvrtc_dir) as raster:
        report["hardware"] = raster.info
        report["occlusion_control"] = occlusion_control(recon, raster)
        for label, mesh, uv, trajectory, native, previous, windows in inputs:
            expected_hits, candidate_hits = [], []

            def measure(target, history):
                def run(*a, **kw):
                    result = target(*a, **kw)
                    history.append(result)
                    return result
                return run

            with patch.object(recon, "raster_hits", measure(cpu_raster, expected_hits)):
                cpu, cpu_stats, _ = recon.simulate(mesh, uv, trajectory, cfg)
            if not args.fixture_dir and not np.array_equal(cpu, previous):
                raise RuntimeError(f"{label}: current CPU reference does not reproduce the saved baseline")
            launches = raster.launches
            with patch.object(recon, "raster_hits", measure(raster, candidate_hits)):
                candidate, cuda_stats, _ = recon.simulate(mesh, uv, trajectory, cfg)
            hit_diffs = [{"sample_index": j, "fields": fields}
                         for j, (a, b) in enumerate(zip(expected_hits, candidate_hits, strict=True))
                         if (fields := differences(a, b))]
            row = {"run": label, "cuda_kernel_launches": raster.launches - launches,
                   "cuda_raster_hits_differences_vs_cpu": hit_diffs,
                   "cpu_vs_saved_cpu": compare(previous, cpu),
                   "cuda_vs_cpu": compare(cpu, candidate),
                   "cuda_vs_native_eps": compare(native, candidate),
                   "cpu_wall_seconds": cpu_stats["wall_seconds"],
                   "cuda_hybrid_wall_seconds": cuda_stats["wall_seconds"]}
            if windows is not None:
                row["cuda_vs_windows_cuda"] = compare(windows, candidate)
            report["results"].append(row)
            np.savez_compressed(args.output_dir / f"{label}-cuda-deposition.npz", values=candidate)
            print(f"{label}: {row['cuda_kernel_launches']} CUDA launches, "
                  f"CPU diff={row['cuda_vs_cpu']['different_texels']}, "
                  f"native diff={row['cuda_vs_native_eps']['different_texels']}, "
                  f"CUDA total={row['cuda_vs_native_eps']['candidate_total']}", flush=True)
    report_name = "cuda-windows-report.json" if os.name == "nt" else "cuda-linux-report.json"
    (args.output_dir / report_name).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
