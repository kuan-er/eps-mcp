// Orthographic EPS replay. Scan faces in their original order and keep
// coverage, pixel shader output, and compute reduction separately observable.

static __device__ double clamp_unit(double x) {
    return fmax(-1.0, fmin(1.0, x));
}

static __device__ void add_metric(unsigned* dst, double value, float scale) {
    atomicAdd(dst, (unsigned)__float2int_rn((float)value * scale));
}

static __device__ bool covers_edge(double dx, double dy, double edge, double area) {
    if (area < 0.0) {
        dx = -dx; dy = -dy; edge = -edge;
    }
    return edge > 0.0 || (edge == 0.0 && (dy < 0.0 || (dy == 0.0 && dx > 0.0)));
}

static __device__ float native_reciprocal(float value) {
    float result;
    asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(result) : "f"(value));
    return result;
}

extern "C" __global__ void clip_depth_reciprocals(float* distances, int count) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i < count) distances[i] = native_reciprocal(distances[i]);
}

extern "C" __global__ void project_native_vertices(
    const float* world, const float* view, const float* projection, int vertex_count, float* clip
) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i >= vertex_count) return;
    const float* p = world + 3*i;
    for (int col = 0; col < 4; ++col) {
        float m[4];
        for (int row = 0; row < 4; ++row) {
            const float* v = view + 4*row;
            // System.Numerics Matrix4x4 uses Vector4.Transform with the
            // x, y, z, w multiply-add chain on the reference EPS host.
            float sum = __fmul_rn(v[0], projection[col]);
            sum = __fmaf_rn(v[1], projection[4+col], sum);
            sum = __fmaf_rn(v[2], projection[8+col], sum);
            m[row] = __fmaf_rn(v[3], projection[12+col], sum);
        }
        // EPS VSMain's compiled DXBC multiplies y first and then adds x, z, w.
        float sum = __fmul_rn(p[1], m[1]);
        sum = __fmaf_rn(p[0], m[0], sum);
        sum = __fmaf_rn(p[2], m[2], sum);
        clip[4*i+col] = __fadd_rn(sum, m[3]);
    }
}

static __device__ float half_target(float value) {
    unsigned short packed;
    float unpacked;
    asm("cvt.rz.f16.f32 %0, %1;" : "=h"(packed) : "f"(value));
    asm("cvt.f32.f16 %0, %1;" : "=f"(unpacked) : "h"(packed));
    return unpacked;
}

static __device__ int native_uv_index(float value, int side) {
    float frac = value - floorf(value);
    return min(side - 1, (int)floorf(frac * side));
}

// The nodes are integer floors of the exact reciprocal on the 1/256 grid.
__device__ __constant__ int reciprocal_nodes[257] = {
    67108864, 66847740, 66588640, 66331541, 66076419, 65823253, 65572019, 65322696,
    65075262, 64829695, 64585974, 64344079, 64103989, 63865684, 63629145, 63394351,
    63161283, 62929923, 62700252, 62472251, 62245902, 62021188, 61798090, 61576592,
    61356675, 61138324, 60921521, 60706251, 60492497, 60280242, 60069472, 59860171,
    59652323, 59445914, 59240928, 59037351, 58835168, 58634365, 58434929, 58236844,
    58040098, 57844677, 57650567, 57457756, 57266230, 57075977, 56886984, 56699238,
    56512727, 56327439, 56143363, 55960485, 55778796, 55598282, 55418932, 55240736,
    55063683, 54887760, 54712959, 54539267, 54366674, 54195170, 54024745, 53855389,
    53687091, 53519841, 53353631, 53188449, 53024287, 52861135, 52698985, 52537826,
    52377649, 52218447, 52060209, 51902928, 51746593, 51591198, 51436734, 51283191,
    51130563, 50978840, 50828015, 50678080, 50529027, 50380848, 50233535, 50087082,
    49941480, 49796722, 49652801, 49509709, 49367440, 49225986, 49085340, 48945496,
    48806446, 48668184, 48530703, 48393997, 48258059, 48122882, 47988461, 47854788,
    47721858, 47589665, 47458202, 47327463, 47197442, 47068134, 46939533, 46811632,
    46684427, 46557911, 46432078, 46306925, 46182444, 46058630, 45935479, 45812984,
    45691141, 45569944, 45449389, 45329470, 45210182, 45091520, 44973479, 44856055,
    44739242, 44623036, 44507433, 44392426, 44278013, 44164188, 44050946, 43938284,
    43826196, 43714679, 43603728, 43493339, 43383508, 43274229, 43165500, 43057316,
    42949672, 42842566, 42735992, 42629948, 42524428, 42419430, 42314948, 42210980,
    42107522, 42004570, 41902119, 41800168, 41698711, 41597746, 41497268, 41397275,
    41297762, 41198727, 41100165, 41002074, 40904450, 40807290, 40710590, 40614347,
    40518559, 40423221, 40328331, 40233885, 40139881, 40046315, 39953184, 39860485,
    39768215, 39676372, 39584952, 39493952, 39403369, 39313201, 39223445, 39134098,
    39045157, 38956619, 38868482, 38780743, 38693399, 38606447, 38519886, 38433711,
    38347922, 38262514, 38177487, 38092836, 38008560, 37924656, 37841121, 37757954,
    37675151, 37592711, 37510631, 37428908, 37347541, 37266527, 37185864, 37105548,
    37025580, 36945955, 36866672, 36787728, 36709122, 36630851, 36552913, 36475306,
    36398027, 36321076, 36244449, 36168145, 36092162, 36016497, 35941148, 35866115,
    35791394, 35716983, 35642882, 35569087, 35495597, 35422410, 35349525, 35276938,
    35204649, 35132656, 35060957, 34989550, 34918433, 34847604, 34777063, 34706806,
    34636833, 34567141, 34497729, 34428595, 34359738, 34291156, 34222846, 34154809,
    34087042, 34019542, 33952310, 33885343, 33818640, 33752198, 33686018, 33620096,
    33554432
};

static __device__ float raster_reciprocal_trial(float area) {
    unsigned bits = __float_as_uint(fabsf(area));
    int exponent = (bits >> 23) & 255u;
    if (exponent == 0 || exponent == 255) return 1.f / area;
    unsigned fraction = bits & 0x7fffffu;
    int bin = fraction >> 16;
    long long t = (int)(fraction & 65535u) - 32768;
    long long left = reciprocal_nodes[2 * bin];
    long long middle = reciprocal_nodes[2 * bin + 1];
    long long right = reciprocal_nodes[2 * bin + 2];
    // The centered residual has 16 fractional bits. Truncate its square to Q16.
    long long square = ((t*t) >> 16) << 16;
    long long value = (middle << 31) + (right - left)*t*32768LL
        + (left + right - 2*middle)*square;
    int mantissa = (int)((value + (1LL << 32)) >> 33);
    return copysignf(ldexpf((float)mantissa, 103 - exponent), area);
}

struct NativeAttributeSetup {
    int anchor, first, reference, last;
    double ax, ay, ux, uy, vx, vy;
    double ox, oy;
    float inv_area;
    bool mixed_gradient, axis_aligned_right;
};

static __device__ bool above(const double* t, int a, int b) {
    return t[a*4+1] < t[b*4+1] ||
           (t[a*4+1] == t[b*4+1] && t[a*4] < t[b*4]);
}

static __device__ unsigned magnitude_minima(const double* t, unsigned allowed) {
    unsigned later = 0;
    for (int i = 0; i < 3; ++i) {
        if (!(allowed & (1u << i))) continue;
        const double x = t[4*i], y = t[4*i+1];
        for (int j = 0; j < 3; ++j) {
            if (i == j || !(allowed & (1u << j))) continue;
            const double other_x = t[4*j], other_y = t[4*j+1];
            const bool same_signs = (x < 0.0) == (other_x < 0.0) && (y < 0.0) == (other_y < 0.0);
            if (same_signs && fabs(other_x) <= fabs(x) && fabs(other_y) <= fabs(y) &&
                (fabs(other_x) < fabs(x) || fabs(other_y) < fabs(y))) {
                later |= 1u << i;
            }
        }
    }
    return allowed & ~later;
}

static __device__ int gradient_reference_vertex(const double* t, int left, int right, int top, int bottom) {
    const double width = t[right*4] - t[left*4];
    const double height = t[bottom*4+1] - t[top*4+1];
    const bool left_is_end_of_y = t[left*4+1] == t[top*4+1] || t[left*4+1] == t[bottom*4+1];
    const int axis = (width > height || (width == height && left_is_end_of_y)) ? 0 : 1;
    const double min_coord = t[(axis == 0 ? left : top)*4+axis];
    const double max_coord = t[(axis == 0 ? right : bottom)*4+axis];
    const double median_coord = t[axis] + t[4+axis] + t[8+axis] - min_coord - max_coord;
    int reference = -1;
    for (int i = 0; i < 3; ++i) {
        if (t[4*i+axis] == median_coord &&
            (reference < 0 || t[4*i+1-axis] < t[4*reference+1-axis])) reference = i;
    }
    return reference;
}

static __device__ NativeAttributeSetup native_attribute_setup(const double* t, int size) {
    int top = 0, bottom = 0, left = 0, right = 0;
    for (int i = 1; i < 3; ++i) {
        if (above(t, i, top)) top = i;
        if (above(t, bottom, i)) bottom = i;
        if (t[4*i] < t[4*left]) left = i;
        if (t[4*i] > t[4*right]) right = i;
    }
    int mid = 3 - top - bottom;
    int anchor = -1;
    for (int i = 0; i < 3; ++i) {
        const double x = t[i*4], y = t[i*4+1];
        if (x >= 0.0 && x < size && y >= 0.0 && y < size && (anchor < 0 || above(t, i, anchor))) {
            anchor = i;
        }
    }
    // If the top vertex is beyond the right edge, a horizontally visible
    // vertex can anchor the plane even when all vertices lie outside Y.
    if (anchor < 0 && t[4*top] >= size) {
        for (int i = 0; i < 3; ++i) {
            double x = t[4*i];
            if (x >= 0.0 && x < size && (anchor < 0 || above(t, i, anchor))) anchor = i;
        }
    }
    if (anchor < 0) anchor = top;
    // For a horizontal top above the viewport and a vertical left edge,
    // the closer endpoint of that edge anchors setup at the viewport boundary.
    double top_y = t[4*top+1];
    if (anchor == bottom && top_y < 0.0 && top_y == t[4*mid+1] &&
        t[4*top] == t[4*bottom] && -top_y < t[4*bottom+1]) {
        anchor = top;
    }
    // Within the measured screen domain, use the raster source priority
    // when a single visible vertex occupies the earliest region.
    const double rank_limit = fmin(double(size), 256.0);
    bool all_in_domain = true;
    int best_priority = 15;
    unsigned positive_sources = 0;
    for (int i = 0; i < 3; ++i) {
        const double x = t[4*i], y = t[4*i+1];
        if (!(x >= 0.0 && x < rank_limit && y >= 0.0 && y < rank_limit)) {
            all_in_domain = false;
            break;
        }
        const bool right = x >= 128.0;
        const bool bottom_half = y >= 128.0;
        const int diagonal = int(right) + int(bottom_half);
        int subregion;
        if (diagonal == 1) {
            subregion = right ? int(y/32.0) : (x < 32.0 ? 0 : (x < 64.0 ? 4 : 5));
        } else {
            subregion = int(x >= (right ? 192.0 : 64.0)) +
                        int(y >= (bottom_half ? 192.0 : 64.0));
        }
        const int priority = 6*diagonal + subregion;
        if (priority < best_priority) {
            best_priority = priority;
            positive_sources = 1u << i;
        } else if (priority == best_priority) {
            positive_sources |= 1u << i;
        }
    }
    if (all_in_domain) {
        if (positive_sources & (positive_sources - 1u)) {
            // The two top-right bands from Y=64 through 127 compare the
            // remaining X=192 boundary before comparing vertex magnitudes.
            if (best_priority == 8 || best_priority == 9) {
                unsigned left_half = 0;
                for (int i = 0; i < 3; ++i) {
                    if (t[4*i] < 192.0) left_half |= positive_sources & (1u << i);
                }
                if (left_half) positive_sources = left_half;
            }
            positive_sources = magnitude_minima(t, positive_sources);
        }
        if (!(positive_sources & (positive_sources - 1u))) anchor = __ffs(positive_sources) - 1;
    }
    if (!all_in_domain && size == 256) {
        // The highest occupied subpixel bit establishes the first square
        // containing a vertex. At that bit, one occupied axis precedes two.
        best_priority = 99;
        unsigned allowed = 0;
        bool guard_band_in_domain = true;
        bool has_small_vertex = false;
        int dominant_axis[3] = {-1, -1, -1};
        int subordinate_bits[3] = {0, 0, 0};
        for (int i = 0; i < 3; ++i) {
            const double x = fabs(t[4*i]), y = fabs(t[4*i+1]);
            if (!(x < 8192.0 && y < 8192.0)) {
                guard_band_in_domain = false;
                continue;
            }
            has_small_vertex |= x < 256.0 && y < 256.0;
            const unsigned sx = __double2uint_rz(x * 256.0);
            const unsigned sy = __double2uint_rz(y * 256.0);
            const unsigned magnitude = sx | sy;
            int priority = 0;
            if (magnitude != 0) {
                const int highest_bit = 31 - __clz(magnitude);
                const unsigned mask = 1u << highest_bit;
                const bool x_occupied = (sx & mask) != 0;
                const bool y_occupied = (sy & mask) != 0;
                priority = 1 + 3*highest_bit + int(x_occupied) + int(y_occupied);
                if (x_occupied != y_occupied) {
                    dominant_axis[i] = x_occupied ? 0 : 1;
                    subordinate_bits[i] = 32 - __clz(min(sx, sy));
                }
            }
            if (priority < best_priority) {
                best_priority = priority;
                allowed = 1u << i;
            } else if (priority == best_priority) {
                allowed |= 1u << i;
            }
        }
        if (!has_small_vertex && !guard_band_in_domain) allowed = 0;
        if (allowed & (allowed - 1u)) {
            unsigned axis_minima[2] = {0, 0};
            int axis_bits[2] = {33, 33};
            for (int i = 0; i < 3; ++i) {
                const int axis = dominant_axis[i];
                if (axis < 0 || !(allowed & (1u << i))) continue;
                const int bits = subordinate_bits[i];
                if (bits < axis_bits[axis]) {
                    axis_bits[axis] = bits;
                    axis_minima[axis] = 1u << i;
                } else if (bits == axis_bits[axis]) {
                    axis_minima[axis] |= 1u << i;
                }
            }
            // A tied shell with one occupied axis compares the highest bit
            // of the other coordinate. X precedes Y at an equal bit or below.
            if (axis_minima[0] || axis_minima[1]) {
                allowed = axis_minima[0] | (axis_bits[0] <= axis_bits[1] ? 0u : axis_minima[1]);
                if (axis_minima[0] && axis_minima[1] && axis_bits[0] > axis_bits[1]) {
                    const unsigned shell = 1u << ((best_priority - 1) / 3);
                    const unsigned x_subordinate = axis_bits[0] ? 1u << (axis_bits[0] - 1) : 0u;
                    const unsigned y_subordinate = axis_bits[1] ? 1u << (axis_bits[1] - 1) : 0u;
                    const unsigned boundary = 32u * 256u;
                    if (shell >= 64u*256u && shell <= 256u*256u &&
                        y_subordinate < boundary && x_subordinate >= boundary) {
                        allowed = axis_minima[1];
                    } else if ((shell == 64u*256u || shell == 128u*256u) && y_subordinate >= boundary) {
                        allowed = axis_minima[0];
                    } else if (shell == 128u*256u && x_subordinate < boundary) {
                        if (y_subordinate >= 2u*256u) {
                            allowed = axis_minima[0];
                        } else if (x_subordinate >= 4u*256u) {
                            allowed = axis_minima[1];
                        }
                    }
                }
                // With the same subordinate sign and bit, positive dominant
                // coordinates precede negative ones on that axis.
                unsigned later = 0;
                for (int i = 0; i < 3; ++i) {
                    const int axis = dominant_axis[i];
                    if (axis < 0 || !(allowed & (1u << i)) || t[4*i+axis] >= 0.0) continue;
                    const double sub = t[4*i+1-axis];
                    if (sub == 0.0) continue;
                    for (int j = 0; j < 3; ++j) {
                        if (!(allowed & (1u << j)) || dominant_axis[j] != axis || t[4*j+axis] < 0.0) continue;
                        const double other_sub = t[4*j+1-axis];
                        if (other_sub != 0.0 && (sub < 0.0) == (other_sub < 0.0)) later |= 1u << i;
                    }
                }
                allowed &= ~later;
            }
            allowed = magnitude_minima(t, allowed);
        }
        if (allowed && !(allowed & (1u << anchor))) {
            int first = -1, visible = -1, horizontal = -1;
            for (int i = 0; i < 3; ++i) {
                if (!(allowed & (1u << i))) continue;
                const double x = t[4*i], y = t[4*i+1];
                if (first < 0 || above(t, i, first)) first = i;
                if (x >= 0.0 && x < size) {
                    if (horizontal < 0 || above(t, i, horizontal)) horizontal = i;
                    if (y >= 0.0 && y < size && (visible < 0 || above(t, i, visible))) visible = i;
                }
            }
            anchor = visible >= 0 ? visible : (t[4*top] >= size && horizontal >= 0 ? horizontal : first);
            if (anchor == bottom && (allowed & (1u << top)) && top_y < 0.0 && top_y == t[4*mid+1] &&
                t[4*top] == t[4*bottom] && -top_y < t[4*bottom+1]) {
                anchor = top;
            }
        }
    }
    const bool horizontal_edge = t[1] == t[5] || t[1] == t[9] || t[5] == t[9];
    const bool vertical_edge = t[0] == t[4] || t[0] == t[8] || t[4] == t[8];
    // The controlling edge is unresolved only when both viewport extents tie
    // and at least one projected coordinate is repeated.
    bool mixed_gradient = (t[4*right] - t[4*left] != t[4*bottom+1] - t[4*top+1]) ||
                          !(horizontal_edge || vertical_edge);
    int reference = mixed_gradient ? gradient_reference_vertex(t,left,right,top,bottom) : mid;
    if (reference < 0) {
        reference = mid;
        mixed_gradient = false;
    }
    const int first = mixed_gradient ? (reference == 0 ? 1 : 0) : top;
    const int last = mixed_gradient ? 3 - reference - first : bottom;
    const double ax = t[4*anchor], ay = t[4*anchor+1];
    const double ux = t[4*first] - t[4*reference], uy = t[4*first+1] - t[4*reference+1];
    const double vx = t[4*last] - t[4*reference], vy = t[4*last+1] - t[4*reference+1];
    int last_tile = ((size - 1)/4)*4;
    double ox = fmin(floor(fmax(t[4*top], 0.0)/4.0)*4.0, last_tile);
    double oy = fmin(floor(fmax(t[4*top+1], 0.0)/4.0)*4.0, last_tile);
    float area = __double2float_rz(ux*vy - uy*vx);
    return {anchor, first, reference, last, ax, ay, ux, uy, vx, vy, ox, oy,
            raster_reciprocal_trial(area), mixed_gradient, horizontal_edge && vertical_edge};
}

static __device__ double truncate_setup_sum(double a, double b, double c, int guard_bits) {
    int exponent;
    frexp(fmax(fabs(a), fmax(fabs(b), fabs(c))), &exponent);
    double step = ldexp(1.0, exponent - (24 + guard_bits));
    return (trunc(a/step) + trunc(b/step) + trunc(c/step)) * step;
}

static __device__ long long round_booth_partial(long long value) {
    const long long magnitude = value < 0 ? -value : value;
    const long long rounded = (magnitude + (1LL << 16)) & ~((1LL << 17) - 1);
    return value < 0 ? -rounded : rounded;
}

static __device__ double raster_gradient_product(float edge, float delta, int* pre_exponent = nullptr) {
    if (edge == 0.0f || delta == 0.0f) return 0.0;
    int edge_exponent, delta_exponent;
    const unsigned multiplicand = (unsigned)ldexp(frexp(fabs((double)edge), &edge_exponent), 24);
    const unsigned multiplier = (unsigned)ldexp(frexp(fabs((double)delta), &delta_exponent), 24);
    const long long low = (multiplier & 1u) ? multiplicand : 0;
    long long product = (long long)multiplicand * multiplier + (1LL << 20);
    product += round_booth_partial(low) - low;
    // The lowest multiplier bit is separate from the Booth-encoded upper bits.
    const unsigned upper = multiplier & ~1u;
    for (int shift = 1; shift < 17; shift += 2) {
        const unsigned code = (upper >> (shift - 1)) & 7u;
        const int digit = (int)(code & 1u) + (int)((code >> 1) & 1u) - (int)((code & 4u) >> 1);
        const long long partial = ((long long)multiplicand << shift) * digit;
        product += round_booth_partial(partial) - partial;
    }
    if (pre_exponent) *pre_exponent = edge_exponent + delta_exponent;
    const double value = ldexp((double)product, edge_exponent + delta_exponent - 48);
    return ((edge < 0.0f) != (delta < 0.0f)) ? -value : value;
}

static __device__ float native_setup_gradient(double edge_a, double attr_a, double edge_b, double attr_b,
                                               double reference, bool mixed_gradient, bool axis_aligned_right) {
    if (mixed_gradient) {
        const float da = __double2float_rz(truncate_setup_sum(attr_a,-reference,0.0,1));
        const float db = __double2float_rz(truncate_setup_sum(attr_b,-reference,0.0,1));
        int pre_a, pre_b;
        const double a = raster_gradient_product((float)edge_a,da,&pre_a);
        const double b = raster_gradient_product((float)edge_b,db,&pre_b);
        if (a == 0.0 || b == 0.0) return __double2float_rz(a+b);
        // The products align before mantissa renormalization. Three extra
        // significand bits are retained in the common exponent.
        const double step = ldexp(1.0,max(pre_a,pre_b)-27);
        return __double2float_rz((trunc(a/step)+trunc(b/step))*step);
    }
    const double a = edge_a * (attr_a - reference);
    const double b = edge_b * (attr_b - reference);
    // Normalized edge operands have been checked independently for this geometry.
    if (axis_aligned_right) {
        if (a == 0.0) {
            float delta = __double2float_rz(truncate_setup_sum(attr_b, -reference, 0.0, 1));
            return __double2float_rz(raster_gradient_product((float)edge_b, delta));
        }
        if (b == 0.0) {
            float delta = __double2float_rz(truncate_setup_sum(attr_a, -reference, 0.0, 1));
            return __double2float_rz(raster_gradient_product((float)edge_a, delta));
        }
    }
    return __double2float_rz(truncate_setup_sum(a, b, 0.0, 1));
}

static __device__ float evaluate_native_attribute(double c, double gx, double gy,
                                                   double ox, double oy, int col, int row) {
    if (gx == 0.0 && gy == 0.0) return (float)c;
    int gradient_exponent;
    frexp(fmax(fabs(gx), fabs(gy)), &gradient_exponent);
    int quantum_exponent = gradient_exponent - 30;
    if (c != 0.0) {
        int constant_exponent;
        frexp(fabs(c), &constant_exponent);
        quantum_exponent = max(quantum_exponent, constant_exponent - 42);
    }
    const double scale = ldexp(1.0, -quantum_exponent);
    const double sx = gx * scale, sy = gy * scale;
    // The quad center uses full accumulator units. The two half-pixel
    // offsets use separately truncated increments in groups of eight units.
    const double center_x = floor(((col | 1) - ox) * sx);
    const double center_y = floor(((row | 1) - oy) * sy);
    const double half_x = trunc(sx / 16.0) * ((col & 1) ? 8.0 : -8.0);
    const double half_y = trunc(sy / 16.0) * ((row & 1) ? 8.0 : -8.0);
    double units = trunc(c * scale) + center_x + center_y + half_x + half_y;
    if (units < 0.0) units += 1.0;
    return __double2float_rz(ldexp(units, quantum_exponent));
}

struct NativeOffsetProduct {
    double value;
    int exponent;
};

static __device__ NativeOffsetProduct native_offset_product(double gradient, double offset) {
    const double exact = gradient * offset;
    if (exact == 0.0) return {exact, -1074};
    int gradient_exponent, offset_exponent;
    const double fraction = frexp(fabs(gradient), &gradient_exponent);
    frexp(fabs(offset), &offset_exponent);
    const int alignment_exponent = gradient_exponent + offset_exponent - 1;
    const double subpixels = fabs(offset) * 256.0;
    if (!(subpixels >= 32.0 && subpixels <= 0xffffff)) return {exact, alignment_exponent};
    const unsigned ticks = __double2uint_rz(subpixels);
    if ((double)ticks != subpixels) return {exact, alignment_exponent};
    const unsigned mantissa = (unsigned)ldexp(fraction, 24);
    // The highest offset bit sets the cutoff for the radix-2 partial products.
    const int discard = 27 - __clz(ticks);
    const unsigned mask = (1u << discard) - 1;
    unsigned loss = 0;
    for (unsigned bits = ticks & mask; bits != 0; bits &= bits - 1) {
        loss += (mantissa << (__ffs(bits) - 1)) & mask;
    }
    const unsigned long long product = (unsigned long long)mantissa * ticks - loss;
    return {copysign(ldexp((double)product, gradient_exponent - 32), exact), alignment_exponent};
}

static __device__ float native_setup_intercept(double attribute, double gx, double gy,
                                               double dx, double dy) {
    const NativeOffsetProduct x = native_offset_product(gx, dx);
    const NativeOffsetProduct y = native_offset_product(gy, dy);
    if (x.value == 0.0 && y.value == 0.0) return (float)attribute;
    int exponent = max(x.exponent, y.exponent);
    if (attribute != 0.0) {
        int attribute_exponent;
        frexp(fabs(attribute), &attribute_exponent);
        exponent = max(exponent, attribute_exponent);
    }
    // Align to the product exponents before any normalization carry.
    const double step = ldexp(1.0, exponent - 29);
    const double sum = trunc(attribute / step) + trunc(x.value / step) + trunc(y.value / step);
    return __double2float_rz(sum * step);
}

static __device__ float interpolate_native_attribute(const NativeAttributeSetup& s, const double* p,
                                                      int stride, double x, double y) {
    double va = p[s.anchor*stride];
    double middle = p[s.reference*stride];
    double first = p[s.first*stride], last = p[s.last*stride];
    double vy = __double2float_rz(s.vy*s.inv_area), uy = __double2float_rz(s.uy*s.inv_area);
    double ux = __double2float_rz(s.ux*s.inv_area), vx = __double2float_rz(s.vx*s.inv_area);
    double gx = native_setup_gradient(vy, first, -uy, last, middle, s.mixed_gradient, s.axis_aligned_right);
    double gy = native_setup_gradient(ux, last, -vx, first, middle, s.mixed_gradient, s.axis_aligned_right);
    double c = native_setup_intercept(va, gx, gy, s.ox-s.ax, s.oy-s.ay);
    return evaluate_native_attribute(c, gx, gy, s.ox, s.oy, (int)x, (int)y);
}

static __device__ float native_dot3(float ax, float ay, float az, float bx, float by, float bz) {
    // The reference NVIDIA DXBC path evaluates dp3 as FMUL and two ordered FFMAs.
    return __fmaf_rn(az, bz, __fmaf_rn(ay, by, __fmul_rn(ax, bx)));
}

static __device__ float native_rsqrt(float squared) {
    float result;
    asm("rsqrt.approx.ftz.f32 %0, %1;" : "=f"(result) : "f"(squared));
    return result;
}

static __device__ float native_sqrt(float squared) {
    float result;
    asm("sqrt.approx.ftz.f32 %0, %1;" : "=f"(result) : "f"(squared));
    return result;
}

static __device__ float native_pixel_ndc(int coordinate, float inverse_size) {
    // The native reduction shader divides via a hardware reciprocal and a separate multiply.
    float center = __fadd_rn(__int2float_rn(coordinate), 0.5f);
    float unit = __fmul_rn(center, inverse_size);
    return __fadd_rn(__fmul_rn(unit, 2.f), -1.f);
}

static __device__ void reduce_native_pixel(
    unsigned* aggregates, unsigned texel, int row, int col, int size,
    float px, float py, float pz, float nx, float ny, float nz, float raw_z,
    const double* camera
) {
    float dx = (float)camera[0] - px, dy = (float)camera[1] - py, dz = (float)camera[2] - pz;
    float distance_squared = native_dot3(dx, dy, dz, dx, dy, dz);
    float distance = native_sqrt(distance_squared);
    float inverse_distance = native_rsqrt(distance_squared);
    float inverse_normal_length = native_rsqrt(native_dot3(nx, ny, nz, nx, ny, nz));
    nx *= inverse_normal_length; ny *= inverse_normal_length; nz *= inverse_normal_length;
    float incidence = native_dot3(nx, ny, nz, dx*inverse_distance, dy*inverse_distance, dz*inverse_distance);
    float fx = (float)camera[3], fy = (float)camera[4], fz = (float)camera[5];
    float inverse_forward_length = native_rsqrt(native_dot3(fx, fy, fz, fx, fy, fz));
    float forward_cos = native_dot3(nx, ny, nz, -fx*inverse_forward_length, -fy*inverse_forward_length,
                                    -fz*inverse_forward_length);
    unsigned* dst = aggregates + texel * 7;
    atomicAdd(dst, 1u);
    add_metric(dst + 1, distance, 1000.f);
    add_metric(dst + 2, clamp_unit(incidence), 1000000.f);
    add_metric(dst + 3, clamp_unit(forward_cos), 1000000.f);
    add_metric(dst + 4, clamp_unit(raw_z), 1000000.f);
    float inverse_size = native_reciprocal(__int2float_rn(size));
    add_metric(dst + 5, native_pixel_ndc(col, inverse_size), 1000000.f);
    add_metric(dst + 6, -native_pixel_ndc(row, inverse_size), 1000000.f);
}

extern "C" __global__ void reduce_native_capture(
    const unsigned* texel, const float* position, const float* normal,
    const double* camera, int size, int side, unsigned* aggregates
) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i >= size*size || position[4*i+3] == 0.f || texel[i] >= (unsigned)(side*side)) return;
    const float* p = position + 4*i;
    const float* n = normal + 4*i;
    reduce_native_pixel(aggregates, texel[i], i / size, i % size, size,
                        p[0], p[1], p[2], n[0], n[1], n[2], n[3], camera);
}

extern "C" __global__ void finalize_native_hits(unsigned* aggregates, int texel_count) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i >= texel_count) return;
    unsigned* cell = aggregates + 7*i;
    if (cell[0] == 0) return;

    float count = __uint2float_rn(cell[0]);
    float inverse_count = native_reciprocal(count);

    // Keep the observed CSFinalize multiplication order. Cosine and NDC use
    // a shared scale coefficient while distance scales the integer sum first.
    const int* sums = reinterpret_cast<const int*>(cell);
    float distance = __fmul_rn(__int2float_rn(sums[1]), 1e-3f);
    cell[1] = __float_as_uint(__fmul_rn(distance, inverse_count));
    float angular_scale = __fmul_rn(1e-6f, inverse_count);
    for (int metric = 2; metric < 7; ++metric) {
        cell[metric] = __float_as_uint(__fmul_rn(__int2float_rn(sums[metric]), angular_scale));
    }
}

extern "C" __global__ void raster_hits(
    const double* screen_z, const double* world_xyz, const double* normals,
    const double* texcoords, const double* camera,
    int face_count, int size, int side, double near_z, double far_z,
    unsigned* aggregates, int native_camera, unsigned* pixel_data
) {
    int index = blockDim.x * blockIdx.x + threadIdx.x;
    if (index >= size * size) return;
    int row = index / size, col = index % size;
    double x = col + 0.5, y = row + 0.5;
    double depth = 1.7976931348623157e308;
    int best = -1;
    double bu = 0, bv = 0, bw = 0;
    for (int face = 0; face < face_count; ++face) {
        const double* t = screen_z + face * 12;
        double ax = t[0], ay = t[1], bx = t[4], by = t[5], cx = t[8], cy = t[9];
        if (x < fmin(ax, fmin(bx, cx)) || x > fmax(ax, fmax(bx, cx)) ||
            y < fmin(ay, fmin(by, cy)) || y > fmax(ay, fmax(by, cy))) continue;
        double denom = (by-cy)*(ax-cx) + (cx-bx)*(ay-cy);
        if (fabs(denom) < 1e-12) continue;
        double u, v, w;
        if (native_camera) {
            double e0 = (cx-bx)*(y-by) - (cy-by)*(x-bx);
            double e1 = (ax-cx)*(y-cy) - (ay-cy)*(x-cx);
            double e2 = (bx-ax)*(y-ay) - (by-ay)*(x-ax);
            if (!covers_edge(cx-bx, cy-by, e0, denom) ||
                !covers_edge(ax-cx, ay-cy, e1, denom) ||
                !covers_edge(bx-ax, by-ay, e2, denom)) continue;
            u = e0/denom; v = e1/denom; w = e2/denom;
        } else {
            u = ((by-cy)*(x-cx) + (cx-bx)*(y-cy)) / denom;
            v = ((cy-ay)*(x-cx) + (ax-cx)*(y-cy)) / denom;
            w = 1.0 - u - v;
            if (u < -1e-10 || v < -1e-10 || w < -1e-10) continue;
        }
        double z = u*t[2] + v*t[6] + w*t[10];
        if (z < near_z || (native_camera ? z >= far_z || z >= depth
                                         : z > far_z || z >= depth - 1e-10)) continue;
        depth = z;
        best = face;
        bu = u; bv = v; bw = w;
    }
    if (best < 0) return;
    const double* uv = texcoords + best * 6;
    const double* t = screen_z + best * 12;
    double tu = bu*uv[0] + bv*uv[2] + bw*uv[4];
    double tv = bu*uv[1] + bv*uv[3] + bw*uv[5];
    NativeAttributeSetup setup{};
    if (native_camera) setup = native_attribute_setup(t, size);
    float w = native_camera ? native_reciprocal(interpolate_native_attribute(setup, t + 3, 4, x, y)) : 1.f;
    int texel_u = native_camera ? native_uv_index(__fmul_rz(w, interpolate_native_attribute(setup, uv, 2, x, y)), side) :
        min(side - 1, (int)floor((tu - floor(tu)) * side));
    int texel_v = native_camera ? native_uv_index(__fmul_rz(w, interpolate_native_attribute(setup, uv + 1, 2, x, y)), side) :
        min(side - 1, (int)floor((tv - floor(tv)) * side));
    unsigned texel = texel_v * side + texel_u;
    unsigned* dst = aggregates + texel * 7;
    const double* p = world_xyz + best * 9;
    const double* n = normals + best * 3;
    if (native_camera) {
        float px = __fmul_rz(w, interpolate_native_attribute(setup, p, 3, x, y));
        float py = __fmul_rz(w, interpolate_native_attribute(setup, p + 1, 3, x, y));
        float pz = __fmul_rz(w, interpolate_native_attribute(setup, p + 2, 3, x, y));
        n = normals + best * 9;
        float nx = __fmul_rz(w, interpolate_native_attribute(setup, n, 3, x, y));
        float ny = __fmul_rz(w, interpolate_native_attribute(setup, n + 1, 3, x, y));
        float nz = __fmul_rz(w, interpolate_native_attribute(setup, n + 2, 3, x, y));
        float inverse_normal_length = native_rsqrt(native_dot3(nx, ny, nz, nx, ny, nz));
        nx *= inverse_normal_length; ny *= inverse_normal_length; nz *= inverse_normal_length;
        float raw_z = half_target(nz);
        float dx = (float)camera[0] - px, dy = (float)camera[1] - py, dz = (float)camera[2] - pz;
        float inverse_distance = native_rsqrt(native_dot3(dx, dy, dz, dx, dy, dz));
        if (native_dot3(nx, ny, nz, dx*inverse_distance, dy*inverse_distance, dz*inverse_distance) < 0.f) {
            nx = -nx; ny = -ny; nz = -nz;
        }
        nx = half_target(nx); ny = half_target(ny); nz = half_target(nz);
        px = half_target(px); py = half_target(py); pz = half_target(pz);
        if (pixel_data != nullptr) {
            unsigned* data = pixel_data + 9*index;
            data[0] = texel;
            data[1] = __float_as_uint(px); data[2] = __float_as_uint(py);
            data[3] = __float_as_uint(pz); data[4] = __float_as_uint(1.f);
            data[5] = __float_as_uint(nx); data[6] = __float_as_uint(ny);
            data[7] = __float_as_uint(nz); data[8] = __float_as_uint(raw_z);
        }
        reduce_native_pixel(aggregates, texel, row, col, size, px, py, pz, nx, ny, nz, raw_z, camera);
        return;
    }
    double dx = camera[0] - (bu*p[0] + bv*p[3] + bw*p[6]);
    double dy = camera[1] - (bu*p[1] + bv*p[4] + bw*p[7]);
    double dz = camera[2] - (bu*p[2] + bv*p[5] + bw*p[8]);
    double distance = sqrt(dx*dx + dy*dy + dz*dz);
    double incidence = n[0]*(dx/distance) + n[1]*(dy/distance) + n[2]*(dz/distance);
    double forward_cos = n[0]*(-camera[3]) + n[1]*(-camera[4]) + n[2]*(-camera[5]);
    atomicAdd(dst, 1u);
    add_metric(dst + 1, distance, 1000.f);
    add_metric(dst + 2, clamp_unit(fabs(incidence)), 1000000.f);
    add_metric(dst + 3, clamp_unit(incidence < 0 ? -forward_cos : forward_cos), 1000000.f);
    add_metric(dst + 4, n[2], 1000000.f);
    add_metric(dst + 5, (x/size)*2.0 - 1.0, 1000000.f);
    add_metric(dst + 6, 1.0 - (y/size)*2.0, 1000000.f);
}
