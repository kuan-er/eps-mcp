# EPS CUDA 冻结版 v1

此版本包含经过验收的 CUDA 源码、沉积计算和复现脚本，验证设备为 Windows 上的 RTX 2080 Ti。比对指标是最终整数喷涂网格逐值一致。

- 1609/1616 个固定工况完全一致，其中非零原生网格 1376/1383 个完全一致。
- 包内的 192 个贴面工况中，190 个完全一致。
- 受控 C30 相位 0 和 10 各有 16/16 和 16/16 个步骤完全一致。累计图一致性见 `validation.json`。

## 本地复跑

在解压目录运行下列命令。需要 Python、NumPy、NVIDIA 驱动和 NVRTC。若 NVRTC 不在动态库搜索路径中，传入 `--nvrtc-dir <目录>`。

```text
python -B holdout/evaluate_holdout.py --backend current --implementation cuda --output replay.json
```

`validation.json` 列出全部工况的统计及差异，`receipts/` 保留各批次逐工况回执。普通 Play 的逐次回放需要该次实际时序。此包用于 CUDA 回放，注册 MCP 的部署和 A100 上的这版验收属于独立流程。
