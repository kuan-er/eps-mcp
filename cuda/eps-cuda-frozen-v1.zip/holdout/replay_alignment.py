"""Compare CUDA and native EPS on the same captured orthographic dispatches."""

import argparse
import json
from pathlib import Path

import numpy as np

from eps_kernel import compute
from reconstructed_deposition import camera_basis
from run_cuda_demo import CudaRaster
from verify_deposition import compare


def deposit(hits, parameters, side):
    flat = np.zeros(side * side, dtype=np.int32)
    if hits is not None:
        flat[hits["texel"]] = compute(parameters, hits["ndcx"], hits["ndcy"], hits["distance"],
                                     hits["cosinc"], hits["cosforward"], hits["count"])
    return flat.reshape(side, side)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nvrtc-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    opts = manifest["runtime_options"]
    size, side = opts["OffscreenWidth"], opts["TextureWidth"]
    if (size, side) != (opts["OffscreenHeight"], opts["TextureHeight"]):
        raise ValueError("This replay expects square EPS buffers")
    legacy = {"camera_pixels": 64, "fan_width_mm": 200., "fan_height_mm": 200.,
              "near_plane_m": .001, "far_plane_m": .6}
    report = {"scope": "Single mesh and spray tool, fixed orthographic inputs from native EPS. "
                       "Time scheduling and arbitrary moving-scene parity are outside this replay.",
              "observed_native_configuration": manifest,
              "fixtures": []}
    nvrtc_dir = args.nvrtc_dir.resolve() if args.nvrtc_dir else None
    with CudaRaster(camera_basis, nvrtc_dir) as cuda:
        report["hardware"] = cuda.info
        for case in manifest["fixtures"]:
            label = case["label"]
            params = case["spray_parameters"]
            with np.load(root / f"{label}.npz", allow_pickle=False) as archive:
                inputs = dict(archive)
            geometry = [inputs[k] for k in ("triangles", "normals", "uv")]
            camera = {k: inputs[k] for k in ("view", "projection", "position", "forward")}
            native_hits = {k: inputs[f"native_{k}"] for k in
                           ("texel", "count", "distance", "cosinc", "cosforward", "ndcx", "ndcy")}
            native_grid = inputs["native_grid"]
            old = cuda(*geometry, camera["position"], camera["forward"], inputs["up"], legacy, side)
            hits = cuda.from_native_camera(*geometry, camera, size, side)
            if hits is None:
                raise RuntimeError(f"{label}: no CUDA hits")
            matched = deposit(hits, params, side)
            reference = deposit(native_hits, params, side)
            row = {"label": label, "native_hit_count": len(native_hits["texel"]),
                   "cuda_hit_count": len(hits["texel"]),
                   "cuda_hit_index_and_counts_exact": all(np.array_equal(hits[k], native_hits[k])
                                                         for k in ("texel", "count")),
                   "different_hit_fields": {k: int(np.count_nonzero(hits[k] != native_hits[k]))
                                            for k in native_hits if hits[k].shape == native_hits[k].shape},
                   "same_native_hits_numpy_deposition": compare(native_grid, reference),
                   "before": compare(native_grid, deposit(old, params, side)),
                   "after": compare(native_grid, matched),
                   "after_l1_error": int(np.abs(native_grid.astype(np.int64) - matched).sum())}
            report["fixtures"].append(row)
            np.savez_compressed(args.output_dir / f"{label}-deposition.npz", values=matched)
            print(label, row["before"]["different_texels"], row["after"]["different_texels"],
                  row["after"]["max_abs_difference"], flush=True)
    report["cuda_kernel_launches"] = cuda.launches
    (args.output_dir / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
