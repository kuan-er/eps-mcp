"""Measure coverage, texel addresses, G-buffer values, hit reduction and paint."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

from reconstructed_deposition import camera_basis
from verify_deposition import compare


def compare_hits(expected, candidate):
    if candidate is None:
        candidate = {k: np.empty(0, dtype=v.dtype) for k, v in expected.items()}
    keys, a, b = np.intersect1d(expected["texel"], candidate["texel"], return_indices=True)
    return {"native_texels": len(expected["texel"]), "cuda_texels": len(candidate["texel"]),
            "common_texels": len(keys),
            "fields_different_on_common_texels": {k: int(np.count_nonzero(v[a] != candidate[k][b]))
                                                   for k, v in expected.items() if k != "texel"}}


def compare_raster(expected, actual):
    native = expected["position"][..., 3] != 0
    cuda = actual["position"][..., 3] != 0
    common = native & cuda
    address = common & (expected["texel"] != actual["texel"])
    return {"native_coverage": int(native.sum()), "cuda_coverage": int(cuda.sum()),
            "native_only_pixels": int((native & ~cuda).sum()),
            "cuda_only_pixels": int((cuda & ~native).sum()),
            "different_texel_addresses": int(address.sum()),
            "different_position_pixels": int(np.any(expected["position"][common] !=
                                                    actual["position"][common], axis=1).sum()),
            "different_normal_pixels": int(np.any(expected["normal"][common] !=
                                                  actual["normal"][common], axis=1).sum())}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--backend", choices=("previous", "current"), required=True)
    p.add_argument("--fixture-dir", type=Path)
    p.add_argument("--implementation", type=Path)
    p.add_argument("--stage-details", action="store_true")
    p.add_argument("--nvrtc-dir", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    root = args.fixture_dir.resolve() if args.fixture_dir else Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    sys.path.insert(0, str(args.implementation.resolve() if args.implementation else root / args.backend))
    from run_cuda_demo import CudaRaster
    from replay_alignment import deposit

    nvrtc = args.nvrtc_dir.resolve() if args.nvrtc_dir else None
    result = {"plan_sha256": manifest["plan_sha256"], "backend": args.backend, "fixtures": []}
    with CudaRaster(camera_basis, nvrtc) as cuda:
        result["hardware"] = cuda.info
        for case in manifest["fixtures"]:
            label = case["label"]
            with np.load(root / "fixtures" / f"{label}.npz", allow_pickle=False) as source:
                a = dict(source)
            camera = {k: a[k] for k in ("view", "projection", "position", "forward")}
            native = {k: a[f"hit_{k}"] for k in ("texel", "count", "distance", "cosinc", "cosforward", "ndcx", "ndcy")}
            params = case["spray_parameters"]
            stage_details = args.backend == "current" or args.stage_details
            pixels = {}
            hits = cuda.from_native_camera(a["triangles"], a["normals"], a["uv"], camera, 256, 512,
                                           **({"buffers": pixels} if stage_details else {}))
            expected = a["native_grid"]
            grid = deposit(hits, params, 512)
            paired = case["native_raster_hit_counts_equal"]
            row = {"label": label, "geometry": case["geometry"], "kind": case["kind"],
                   "native_raster_hit_counts_equal": paired,
                   "deposit_from_native_hits": compare(expected, deposit(native, params, 512)),
                   "standalone": compare(expected, grid), "standalone_hits": compare_hits(native, hits),
                   "standalone_grid_sha256": sha256(grid.astype("<i4").tobytes()).hexdigest()}
            if stage_details:
                raw = {k: a[f"raster_{k}"] for k in ("texel", "position", "normal")}
                row["raster"] = compare_raster(raw, pixels)
                row["standalone_raster_sha256"] = {k: sha256(v.tobytes()).hexdigest() for k, v in pixels.items()}
                row["standalone_hit_sha256"] = {k: sha256(hits[k].tobytes()).hexdigest() for k in native} if hits else {}
                reduced = cuda.reduce_native_capture(raw["texel"], raw["position"], raw["normal"], camera, 512)
                from_native_raster = deposit(reduced, params, 512)
                row["native_raster_reduced_on_cuda"] = compare(expected, from_native_raster)
                row["native_raster_cuda_hits"] = compare_hits(native, reduced)
            result["fixtures"].append(row)
            print(label, paired, row["standalone"]["different_texels"],
                  row.get("native_raster_reduced_on_cuda", {}).get("different_texels"), flush=True)
    args.output.parent.mkdir(exist_ok=True, parents=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
