"""Compare raw integer UV deposition grids from EPS and another backend.

Requires NumPy. Accepts .npy arrays or .npz arrays (key "values" by default).
Both inputs must use the same atlas, row origin, and deposition units.
Exit status: 0 = exact match, 1 = different grids, 2 = invalid input.
"""

import argparse
import json

import numpy as np


def read_grid(path, key):
    archive = np.load(path, allow_pickle=False)
    if isinstance(archive, np.lib.npyio.NpzFile):
        with archive:
            grid = archive[key]
    else:
        grid = archive
    if grid.ndim != 2 or not grid.size or grid.dtype.kind not in "iu":
        raise ValueError(f"{path}: expected a nonempty 2-D integer grid")
    return grid


def compare(reference, candidate):
    if reference.shape != candidate.shape:
        raise ValueError(f"UV grid shape differs: {reference.shape} vs {candidate.shape}")
    # Python integers avoid overflow and loss of precision across signed/unsigned dtypes.
    left = reference.astype(object)
    right = candidate.astype(object)
    mismatch = left != right
    differing = int(np.count_nonzero(mismatch))
    report = {
        "exact_match": differing == 0,
        "shape": list(reference.shape),
        "different_texels": differing,
        "reference_total": int(left.sum()),
        "candidate_total": int(right.sum()),
        "max_abs_difference": 0,
        "first_difference": None,
    }
    if differing:
        v, u = map(int, np.unravel_index(mismatch.argmax(), reference.shape))
        report["first_difference"] = {
            "v_row": v, "u_column": u,
            "reference": left[v, u], "candidate": right[v, u],
        }
        report["max_abs_difference"] = int(abs(left[mismatch] - right[mismatch]).max())
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", help="native EPS .npz or .npy")
    parser.add_argument("candidate", help="candidate backend .npz or .npy")
    parser.add_argument("--reference-key", default="values")
    parser.add_argument("--candidate-key", default="values")
    args = parser.parse_args()
    try:
        report = compare(read_grid(args.reference, args.reference_key),
                         read_grid(args.candidate, args.candidate_key))
    except (OSError, KeyError, ValueError) as exc:
        parser.error(str(exc))
    print(json.dumps(report, indent=2))
    return 0 if report["exact_match"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
